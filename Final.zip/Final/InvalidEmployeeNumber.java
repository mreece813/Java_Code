public class InvalidEmployeeNumber extends Exception
{

    public InvalidEmployeeNumber()
    {
        System.out.println("Invalid Employee Number, must be between 1-9999");

    }

    
}
