public class InvalidPayRate extends Exception
{

    public InvalidPayRate()
    {
           System.out.println("Invalid Pay Rate, must be over 0 Dollars");
    }

}