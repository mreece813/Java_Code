public class InvalidShift extends Exception
{

    public InvalidShift()
    {
            System.out.println("Invalid Shift Number, must be a 1(Day) or 2(night)");
    }

}