
public class level1 extends Question
{
    public level1()
    {
       super();
    }

    public String toString() 
    {
        return super.toString();
    } 
}
