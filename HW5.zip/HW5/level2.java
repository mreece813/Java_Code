
public class level2 extends Question
{
    public level2()
    {
       super();
    }

    public String toString() 
    {
        return super.toString();
    } 

}
