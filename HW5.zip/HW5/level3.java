

public class level3 extends Question
{
    public level3()
    {
       super();
    }


    public String toString() 
    {
        return "What is " + num1 + " - " + num2 + "?\n";
    }
}
